systemctl enable boot_leds
