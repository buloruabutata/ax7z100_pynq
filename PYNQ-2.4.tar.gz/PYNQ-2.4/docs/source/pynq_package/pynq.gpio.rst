.. _pynq-gpio:
   
pynq.gpio Module
================

The pynq.gpio module is a driver for reading and writing PS GPIO pins on a
board. PS GPIO pins are not connected to the PL.

.. automodule:: pynq.gpio
    :members:
    :undoc-members:
    :show-inheritance:
