.. _pynq-lib-button:

pynq.lib.button Module
======================

The pynq.lib.rgbled module is a driver for reading values from onboard
push-buttons and waiting for button-triggered events. 

.. automodule:: pynq.lib.button
    :members:
    :undoc-members:
    :show-inheritance:
