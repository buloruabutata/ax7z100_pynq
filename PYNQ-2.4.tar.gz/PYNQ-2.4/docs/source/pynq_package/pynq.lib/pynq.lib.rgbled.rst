pynq.lib.rgbled Module
======================

The pynq.lib.rgbled module is a driver for controlling onboard Red-Green-Blue
(RGB) Light Emitting Diodes (LEDs). 

.. automodule:: pynq.lib.rgbled
    :members:
    :undoc-members:
    :show-inheritance:
