pynq.lib.led Module
===================

The pynq.lib.rgbled module is a driver for controlling onboard single-color
Light Emitting Diodes (LEDs).

.. automodule:: pynq.lib.led
    :members:
    :undoc-members:
    :show-inheritance:
