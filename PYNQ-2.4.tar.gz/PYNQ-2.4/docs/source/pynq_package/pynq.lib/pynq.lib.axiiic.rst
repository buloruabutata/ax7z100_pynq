.. _pynq-lib-axiiic:

pynq.lib.axiiic Module
=======================

The pynq.lib.axiiic module is a driver for interacting with the Xilinx Axi IIC
IP Block.

.. automodule:: pynq.lib.iic
    :members:
    :undoc-members:
    :show-inheritance:
